/* SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: 2016-2020 the prplMesh contributors (see AUTHORS.md)
 *
 * This code is subject to the terms of the BSD+Patent license.
 * See LICENSE file for more details.
 */

#ifndef _DB_ALGO_H
#define _DB_ALGO_H

#include "db.h"

namespace son {
class db_algo {
    /*
         * this class is empty for now
         * but should stay as a placeholder for when it is needed in the future
         */
public:
private:
};

} // namespace son

#endif
