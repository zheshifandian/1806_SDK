This directory is for relevant documentation that should accompany the BeeRocks project code.
