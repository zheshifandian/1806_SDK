# MultiAP Common
This project includes the implementation of shared and reusable components for all MultiAP modules.

The MultiAP controller and agent are external to this project.

## License
<a name="license"></a>
This project is licensed under the BSD+Patent License - see the [LICENSE](LICENSE) file for details

