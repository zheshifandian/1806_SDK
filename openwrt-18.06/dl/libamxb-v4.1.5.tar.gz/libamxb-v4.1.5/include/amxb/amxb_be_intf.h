/****************************************************************************
**
** Copyright (c) 2020 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__AMXB_BE_INTF_H__)
#define __AMXB_BE_INTF_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxb/amxb_types.h>

typedef struct _amxb_bus_ctx amxb_bus_ctx_t;
typedef struct _amxb_request amxb_request_t;
typedef struct _amxb_invoke amxb_invoke_t;

#define AMXB_BE_DISCOVER_DESCRIBE 0x0001
#define AMXB_BE_DISCOVER_LIST     0x0002
#define AMXB_BE_DISCOVER          0x0004

//-----------------------------------------------------------------------------
typedef void*(* amxb_be_connect_fn_t) (const char* host,
                                       const char* port,
                                       const char* path,
                                       amxp_signal_mngr_t* sigmngr);

#define amxb_be_listen_fn_t amxb_be_connect_fn_t

typedef void*(* amxb_be_accept_fn_t) (void* const ctx,
                                      amxp_signal_mngr_t* sigmngr);

typedef int (* amxb_be_disconnect_fn_t) (void* const ctx);
typedef int (* amxb_be_get_fd_fn_t) (void* const ctx);
typedef int (* amxb_be_read_fn_t) (void* const ctx);
typedef int (* amxb_be_read_raw_fn_t) (void* const ctx, void* buf, size_t count);
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
typedef int (* amxb_be_new_invoke_fn_t) (amxb_invoke_t* invoke_ctx);
typedef void (* amxb_be_free_invoke_fn_t) (amxb_invoke_t* invoke_ctx);
typedef int (* amxb_be_invoke_fn_t) (void* const ctx,
                                     amxb_invoke_t* invoke_ctx,
                                     amxc_var_t* args,
                                     amxb_request_t* request,
                                     int timeout);
typedef int (* amxb_be_async_invoke_fn_t) (void* const ctx,
                                           amxb_invoke_t* invoke_ctx,
                                           amxc_var_t* args,
                                           amxb_request_t* request);
typedef int (* amxb_be_close_request_fn_t) (void* const ctx,
                                            amxb_request_t* request);

typedef int (* amxb_be_wait_request_fn_t) (void* const ctx,
                                           amxb_request_t* request,
                                           int timeout);
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
typedef int (* amxb_be_subscribe_fn_t) (void* const ctx,
                                        const char* object);

typedef int (* amxb_be_unsubscribe_fn_t) (void* const ctx,
                                          const char* object);
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
typedef int (* amxb_be_register_fn_t) (void* const ctx,
                                       amxd_dm_t* const dm);
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
typedef void (* amxb_be_free_fn_t) (void* const ctx);
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
typedef int (* amxb_be_get_t) (void* const ctx,
                               const char* object,
                               const char* search_path,
                               int32_t depth,
                               uint32_t access,
                               amxc_var_t* ret,
                               int timeout);

typedef int (* amxb_be_set_t) (void* const ctx,
                               const char* object,
                               const char* search_path,
                               uint32_t flags,
                               amxc_var_t* values,
                               amxc_var_t* ovalues,
                               uint32_t access,
                               amxc_var_t* ret,
                               int timeout);

typedef int (* amxb_be_add_t) (void* const ctx,
                               const char* object,
                               const char* search_path,
                               uint32_t index,
                               const char* name,
                               amxc_var_t* values,
                               uint32_t access,
                               amxc_var_t* ret,
                               int timeout);

typedef int (* amxb_be_del_t) (void* const bus_ctx,
                               const char* object,
                               const char* search_path,
                               uint32_t index,
                               const char* name,
                               uint32_t access,
                               amxc_var_t* ret,
                               int timeout);

typedef int (* amxb_be_get_supported_t) (void* const bus_ctx,
                                         const char* object,
                                         const char* search_path,
                                         uint32_t flags,
                                         amxc_var_t* retval,
                                         int timeout);

typedef int (* amxb_be_describe_t) (void* const bus_ctx,
                                    const char* object,
                                    const char* search_path,
                                    uint32_t flags,
                                    uint32_t access,
                                    amxc_var_t* retval,
                                    int timeout);

typedef int (* amxb_be_list_t) (void* const bus_ctx,
                                const char* object,
                                uint32_t flags,
                                uint32_t access,
                                amxb_request_t* request);

typedef int (* amxb_be_wait_for_fn_t) (void* const bus_ctx,
                                       const char* object);

typedef uint32_t (* amxb_be_capabilities_fn_t) (void* const bus_ctx);

typedef bool (* amxb_be_has_fn_t) (void* const bus_ctx,
                                   const char* object);

//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
typedef int (* amxb_be_set_config_t) (const amxc_var_t* const configuration);
//-----------------------------------------------------------------------------


struct _amxb_be_funcs {
    amxc_htable_it_t it;             /**< reserved for internal use only */
    void* handle;                    /**< reserved for internal use only */
    amxc_llist_t connections;        /**< reserved for internal use only */
    const char* name;
    size_t size;
    amxb_be_connect_fn_t connect;
    amxb_be_disconnect_fn_t disconnect;
    amxb_be_get_fd_fn_t get_fd;
    amxb_be_read_fn_t read;
    amxb_be_new_invoke_fn_t new_invoke;
    amxb_be_free_invoke_fn_t free_invoke;
    amxb_be_invoke_fn_t invoke;
    amxb_be_async_invoke_fn_t async_invoke;
    amxb_be_close_request_fn_t close_request;
    amxb_be_wait_request_fn_t wait_request;
    amxb_be_subscribe_fn_t subscribe;
    amxb_be_unsubscribe_fn_t unsubscribe;
    amxb_be_free_fn_t free;
    amxb_be_register_fn_t register_dm;
    amxb_be_get_t get;
    amxb_be_set_t set;
    amxb_be_add_t add;
    amxb_be_del_t del;
    amxb_be_get_supported_t get_supported;
    amxb_be_set_config_t set_config;
    amxb_be_describe_t describe;
    amxb_be_list_t list;
    amxb_be_listen_fn_t listen;
    amxb_be_accept_fn_t accept;
    amxb_be_read_raw_fn_t read_raw;
    amxb_be_wait_for_fn_t wait_for;
    amxb_be_capabilities_fn_t capabilities;
    amxb_be_has_fn_t has;
};

#ifdef __cplusplus
}
#endif

#endif // __AMXB_BE_INTF_H__
