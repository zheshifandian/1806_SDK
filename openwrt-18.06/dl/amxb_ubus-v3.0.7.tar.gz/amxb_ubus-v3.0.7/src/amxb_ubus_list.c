/****************************************************************************
**
** Copyright (c) 2020 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "amxb_ubus.h"


typedef struct _ubus_filter {
    uint32_t depth;
    const char* path;
    uint32_t path_len;
    char* current;
    uint32_t cur_len;
    uint32_t flags;
    uint32_t access;
    amxb_request_t* request;
} ubus_filter_t;

static int32_t amxb_ubus_object_depth(const char* path) {
    uint32_t length = path == NULL ? 0 : strlen(path);
    int32_t depth = 0;
    for(uint32_t i = 0; i < length; i++) {
        if(path[i] == '.') {
            depth++;
        }
    }

    return depth;
}

static void amxb_ubus_add_functions(struct ubus_object_data* o,
                                    ubus_filter_t* filter,
                                    const char* path,
                                    amxc_var_t* retval) {
    if(o->signature && ((filter->flags & AMXB_FLAG_FUNCTIONS) != 0)) {
        struct blob_attr* cur;
        size_t rem = 0;
        (void) rem; // clang complains about not used variable
        // but rem is needed to be able to use the following macro
        blob_for_each_attr(cur, o->signature, rem) {
            (void) rem; // clang complains about not used variable
            amxc_string_t func_name;
            amxc_string_init(&func_name, 0);
            amxc_string_setf(&func_name, "%s%s", path, blobmsg_name(cur));
            if((filter->access < amxd_dm_access_protected) &&
               ( blobmsg_name(cur)[0] == '_')) {
                amxc_string_clean(&func_name);
                continue;
            }
            amxc_var_add(cstring_t, retval, amxc_string_get(&func_name, 0));
            amxc_string_clean(&func_name);
        }
    }
}

static void amxb_ubus_path_to_depth(amxd_path_t* path,
                                    ubus_filter_t* filter,
                                    uint32_t depth,
                                    bool* add_functions) {
    uint32_t extra_depth = 0;
    if((filter->flags & (AMXB_FLAG_OBJECTS | AMXB_FLAG_INSTANCES)) != 0) {
        extra_depth = 1;
    }

    while(depth > filter->depth + extra_depth) {
        char* part = amxd_path_get_last(path, true);
        free(part);
        *add_functions = false;
        depth--;
    }
}

static void amxb_ubus_update_current_path(ubus_filter_t* filter, const char* path) {
    free(filter->current);
    filter->current = strdup(path);
    filter->cur_len = strlen(path);
}

static void amxb_ubus_objects_cb(AMXB_UNUSED struct ubus_context* c,
                                 struct ubus_object_data* o,
                                 void* p) {
    ubus_filter_t* filter = (ubus_filter_t*) p;
    const char* recv_path = NULL;
    amxd_path_t path;
    amxc_var_t retval;
    uint32_t depth = amxb_ubus_object_depth(o->path) + 1;
    const amxb_bus_ctx_t* bus_ctx = amxb_request_get_ctx(filter->request);

    amxc_var_init(&retval);
    amxc_var_set_type(&retval, AMXC_VAR_ID_LIST);
    amxd_path_init(&path, NULL);
    amxd_path_setf(&path, true, "%s", o->path);
    recv_path = amxd_path_get(&path, AMXD_OBJECT_TERMINATE);

    if(strncmp(recv_path, filter->path, filter->path_len) != 0) {
        goto exit;
    }

    if(depth == filter->depth) {
        if((filter->current != NULL) &&
           ( strncmp(filter->current, recv_path, filter->cur_len) == 0)) {
            goto exit;
        }
        amxb_ubus_add_functions(o, filter, recv_path, &retval);
        amxb_ubus_update_current_path(filter, recv_path);
    } else if(depth > filter->depth) {
        bool functions = true;
        if((filter->flags & AMXB_FLAG_FIRST_LVL) != 0) {
            amxb_ubus_path_to_depth(&path, filter, depth, &functions);

            recv_path = amxd_path_get(&path, AMXD_OBJECT_TERMINATE);
            if((filter->current != NULL) &&
               (( strncmp(filter->current, recv_path, filter->cur_len) == 0) &&
                ( strlen(recv_path) == filter->cur_len))) {
                goto exit;
            }
        }
        amxc_var_add(cstring_t, &retval, recv_path);
        if(functions) {
            amxb_ubus_add_functions(o, filter, recv_path, &retval);
        }
        amxb_ubus_update_current_path(filter, recv_path);
    }

    if(filter->request->cb_fn) {
        filter->request->cb_fn(bus_ctx, &retval, filter->request->priv);
    }

exit:
    amxc_var_clean(&retval);
    amxd_path_clean(&path);
}

static void amxb_ubus_add_to_list(const char* object,
                                  amxc_string_t* full_name,
                                  amxc_var_t* list,
                                  amxc_var_t* retval) {
    if(list != NULL) {
        switch(amxc_var_type_of(list)) {
        case AMXC_VAR_ID_LIST: {
            amxc_var_for_each(name, list) {
                amxc_string_setf(full_name, "%s%s",
                                 object, amxc_var_constcast(cstring_t, name));
                amxc_var_add(cstring_t, retval, amxc_string_get(full_name, 0));
            }
        }
        break;
        case AMXC_VAR_ID_HTABLE: {
            const amxc_htable_t* data = amxc_var_constcast(amxc_htable_t, list);
            amxc_array_t* keys = amxc_htable_get_sorted_keys(data);
            uint32_t size = amxc_htable_size(data);
            for(uint32_t i = 0; i < size; i++) {
                const char* name = (const char*) amxc_array_get_data_at(keys, i);
                amxc_string_setf(full_name, "%s%s", object, name);
                amxc_var_add(cstring_t, retval, amxc_string_get(full_name, 0));
            }
            amxc_array_delete(&keys, NULL);
        }
        break;
        default:
            break;
        }
    }
}

static void amxb_ubus_build_list(amxb_request_t* request,
                                 const char* object,
                                 uint32_t flags,
                                 amxc_var_t* full) {
    amxc_var_t* table = GETI_ARG(full, 0);
    amxc_var_t* obj = GET_ARG(table, "objects");
    amxc_var_t* inst = GET_ARG(table, "instances");
    amxc_var_t* funcs = GET_ARG(table, "functions");
    amxc_var_t* params = GET_ARG(table, "parameters");
    bool named = ((flags & AMXB_FLAG_NAMED) != 0);
    amxc_var_t retval;
    amxc_string_t full_name;
    const amxb_bus_ctx_t* bus_ctx = amxb_request_get_ctx(request);

    amxc_var_init(&retval);
    amxc_var_set_type(&retval, AMXC_VAR_ID_LIST);

    amxc_string_init(&full_name, strlen(object) + 32);
    if(inst) {
        amxc_var_for_each(name, inst) {
            amxc_var_t* var = NULL;
            if(named) {
                var = amxc_var_get_key(name, "name", AMXC_VAR_FLAG_DEFAULT);
                const char* key = amxc_var_constcast(cstring_t, var);
                amxc_string_setf(&full_name, "%s%s.", object, key);
            } else {
                var = amxc_var_get_key(name, "index", AMXC_VAR_FLAG_DEFAULT);
                uint32_t index = amxc_var_dyncast(uint32_t, var);
                amxc_string_setf(&full_name, "%s%d.", object, index);
            }
            amxc_var_add(cstring_t, &retval, amxc_string_get(&full_name, 0));
        }
    }
    amxb_ubus_add_to_list(object, &full_name, params, &retval);
    amxb_ubus_add_to_list(object, &full_name, funcs, &retval);
    amxb_ubus_add_to_list(object, &full_name, obj, &retval);

    if(request->cb_fn) {
        request->cb_fn(bus_ctx, &retval, request->priv);
    }

    amxc_var_clean(&retval);
    amxc_string_clean(&full_name);
    return;
}

static void amxb_ubus_build_list_args(amxc_var_t* args,
                                      uint32_t flags,
                                      uint32_t access,
                                      const char* rel_path) {
    amxc_var_set_type(args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, args, "parameters", (flags & AMXB_FLAG_PARAMETERS) != 0);
    amxc_var_add_key(bool, args, "functions", (flags & AMXB_FLAG_FUNCTIONS) != 0);
    amxc_var_add_key(bool, args, "objects", (flags & AMXB_FLAG_OBJECTS) != 0);
    amxc_var_add_key(bool, args, "instances", (flags & AMXB_FLAG_INSTANCES) != 0);
    amxc_var_add_key(bool, args, "template_info", (flags & AMXB_FLAG_TEMPLATE_INFO) != 0);
    amxc_var_add_key(uint32_t, args, "access", access);
    if((rel_path != NULL) && (*rel_path != 0)) {
        amxc_var_add_key(cstring_t, args, "rel_path", rel_path);
    }
}

static int amxb_ubus_invoke_list(amxb_ubus_t* amxb_ubus_ctx,
                                 const char* object,
                                 uint32_t flags,
                                 uint32_t access,
                                 amxc_var_t* retval) {
    int rv = AMXB_ERROR_BUS_NOT_FOUND;
    amxd_path_t path;
    char* first_lvl = NULL;
    const char* rel_path = NULL;
    amxb_request_t* request = NULL;
    amxc_var_t args;
    uint32_t id = 0;
    size_t first_lvl_len = 0;

    amxc_var_init(&args);
    amxd_path_init(&path, object);
    when_not_null(amxd_path_get_param(&path), exit);

    first_lvl = amxd_path_get_first(&path, true);
    first_lvl_len = strlen(first_lvl);
    if(first_lvl[first_lvl_len - 1] == '.') {
        first_lvl[first_lvl_len - 1] = 0;
    }
    rel_path = amxd_path_get(&path, AMXD_OBJECT_TERMINATE);
    amxb_ubus_build_list_args(&args, flags, access, rel_path);

    when_failed(amxb_request_new(&request), exit);
    request->result = retval;

    rv = amxb_ubus_invoke_base(amxb_ubus_ctx, first_lvl, &args, request, &id);
    when_failed(rv, exit);
    rv = ubus_invoke(amxb_ubus_ctx->ubus_ctx, id, "_list",
                     amxb_ubus_ctx->b.head, amxb_ubus_result_data,
                     request, 5000);

exit:
    if(request != NULL) {
        request->result = NULL;
        amxb_close_request(&request);
    }
    free(first_lvl);
    amxc_var_clean(&args);
    amxd_path_clean(&path);
    return rv;
}

static int amxb_ubus_list_native(amxb_ubus_t* amxb_ubus_ctx,
                                 const char* object,
                                 ubus_filter_t* filter,
                                 amxb_request_t* request) {
    int rv = 0;
    const amxb_bus_ctx_t* bus_ctx = NULL;
    bus_ctx = amxb_request_get_ctx(request);

    if(object[strlen(object) - 1] == '.') {
        amxc_string_t path;

        filter->path = object;
        filter->path_len = strlen(object);
        filter->current = NULL;
        filter->depth = amxb_ubus_object_depth(object);

        amxc_string_init(&path, 0);
        amxc_string_setf(&path, "%s", object);
        amxc_string_set_at(&path, strlen(object) - 1, "*", 1, amxc_string_overwrite);
        rv = ubus_lookup(amxb_ubus_ctx->ubus_ctx,
                         amxc_string_get(&path, 0),
                         amxb_ubus_objects_cb,
                         filter);
        amxc_string_clean(&path);
        request->cb_fn(bus_ctx, NULL, request->priv);
    } else {
        request->cb_fn(bus_ctx, NULL, request->priv);
    }

    return rv;
}

int amxb_ubus_list(void* const ctx,
                   const char* object,
                   uint32_t flags,
                   uint32_t access,
                   amxb_request_t* request) {
    const amxb_bus_ctx_t* bus_ctx = NULL;
    amxb_ubus_t* amxb_ubus_ctx = (amxb_ubus_t*) ctx;
    int rv = -1;
    ubus_filter_t filter;

    memset(&filter, 0, sizeof(ubus_filter_t));
    filter.flags = flags;
    filter.access = access;
    filter.request = request;

    bus_ctx = amxb_request_get_ctx(request);
    if((object == NULL) || (*object == 0)) {
        rv = ubus_lookup(amxb_ubus_ctx->ubus_ctx, NULL, amxb_ubus_objects_cb, &filter);
        request->cb_fn(bus_ctx, NULL, request->priv);
    } else {
        amxc_var_t data;
        amxc_var_init(&data);
        amxc_var_set_type(&data, AMXC_VAR_ID_LIST);
        if((flags & AMXB_FLAG_FIRST_LVL) != 0) {
            rv = amxb_ubus_invoke_list(amxb_ubus_ctx, object, flags, access, &data);
        }
        if(rv == 0) {
            amxb_ubus_build_list(request, object, flags, &data);
            request->cb_fn(bus_ctx, NULL, request->priv);
        } else {
            rv = amxb_ubus_list_native(amxb_ubus_ctx, object, &filter, request);
        }
        amxc_var_clean(&data);
    }

    free(filter.current);
    amxb_close_request(&request);
    return rv;
}